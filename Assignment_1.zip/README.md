# Assignment 1: SQLite
### CPSC 408 - 01: Database Management
### Sarah Fieck, 2374389
## References:
For this project, I used a few online resources that I would like to cite.
- **Array of United States Names:** https://usastatescode.com/state-array-json
- **Searching for Punctuation in a String:** https://www.geeksforgeeks.org/string-punctuation-in-python/
- **Collecting ID Values of a Column:** https://stackoverflow.com/questions/51112900/how-do-i-get-all-values-of-a-column-in-sqlite3
- **Checking if an SQLite Table Exists:** https://tableplus.com/blog/2018/04/sqlite-check-whether-a-table-exists.html
## Files:
- **Assignment1.py**
- **StudentDB**, the SQLite DB that contains the Students table
- **students.csv**, the csv that the table reads from
